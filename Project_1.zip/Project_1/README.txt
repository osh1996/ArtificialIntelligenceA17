David Swenarton dbswenarton@wpi.edu
Tung Truong ttruong@wpi.edu
Chris O'Shea coshea@wpi.edu

use python 3.6 on main.py with input graph filename as a parameter

output will appear in output.txt