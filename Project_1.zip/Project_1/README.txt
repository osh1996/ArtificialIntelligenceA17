David Swenarton dbswenarton@wpi.edu
Tung Truong ttruong@wpi.edu
Chris O'Shea coshea@wpi.edu

use python compiler on file.py to initialize search on graph.txt