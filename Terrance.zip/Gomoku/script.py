import os
os.remove("Terrance.go")
os.remove("Terrance2.go")
#os.remove("Brenda.go")
os.remove("move_file")
os.remove("history_file")
os.remove("end_game")